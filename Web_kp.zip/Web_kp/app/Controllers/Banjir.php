<?php

namespace App\Controllers;

class Banjir extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/banjir');
		echo view('footer');
	}
}
