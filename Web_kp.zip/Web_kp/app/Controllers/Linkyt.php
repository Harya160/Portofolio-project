<?php

namespace App\Controllers;

class Linkyt extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/linkyt');
		echo view('footer');
	}
}
