<?php

namespace App\Controllers;

class Warning extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/warning');
		echo view('footer');
	}
}
