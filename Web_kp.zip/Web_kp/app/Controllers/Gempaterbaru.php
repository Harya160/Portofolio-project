<?php

namespace App\Controllers;

class Gempaterbaru extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/gempaterbaru');
		echo view('footer');
	}
}
