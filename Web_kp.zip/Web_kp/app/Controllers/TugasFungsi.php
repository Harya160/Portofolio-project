<?php

namespace App\Controllers;

class TugasFungsi extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/tugasfungsi');
		echo view('footer');
	}
}