<?php

namespace App\Controllers;

class Gempaterkini extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/gempaterkini');
		echo view('footer');
	}
}
