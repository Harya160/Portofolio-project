<?php

namespace App\Controllers;

class Geofisika extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/geofisika');
		echo view('footer');
	}
}
