<?php

namespace App\Controllers;

use App\Models\FormModel;

class Pengaduan extends BaseController
{
	protected $formModel;
	public function __construct()
	{
		$this->formModel = new FormModel();
	}
	public function index()
	{
		$form = $this->formModel->findAll();

		$data=[
			'form' => $form
		];

		echo view('header');
		echo view('layout/laporan',$data);
		echo view('footer');
	}

	public function save()
	{
		dd($this->request->getVar());

		// $this->FormModel->save([
		// 	'Nama' => $this->request->getVar('Nama'),
		// 	'Nomor Whatsapp' => $this->request->getVar('Nomor Whatsapp'),
		// 	'Alamat' => $this->request->getVar('Alamat'),
		// 	'Tanggal Kejadian' => $this->request->getVar('Tanggal Kejadian'),
		// 	'Aduan' => $this->request->getVar('Aduan')
		// ]);
	}
}
