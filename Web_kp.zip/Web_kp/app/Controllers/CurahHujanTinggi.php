<?php

namespace App\Controllers;

class CurahHujanTinggi extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/curahhujantinggi');
		echo view('footer');
	}
}
