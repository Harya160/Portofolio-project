<?php

namespace App\Controllers;

class Gempadirasakan extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/gempadirasakan');
		echo view('footer');
	}
}
