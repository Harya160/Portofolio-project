<?php

namespace App\Controllers;

class Kekeringan extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/kekeringan');
		echo view('footer');
	}
}
