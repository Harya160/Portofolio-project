<?php

namespace App\Controllers;

class Survey extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/survey');
		echo view('footer');
	}
}