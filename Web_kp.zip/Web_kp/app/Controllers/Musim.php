<?php

namespace App\Controllers;

class Musim extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/musim');
		echo view('footer');
	}
}
