<?php

namespace App\Controllers;

class Meteorologi extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/meteorologi');
		echo view('footer');
	}
}
