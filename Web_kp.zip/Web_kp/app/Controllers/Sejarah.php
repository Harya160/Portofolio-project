<?php

namespace App\Controllers;

class Sejarah extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/sejarah');
		echo view('footer');
	}
}