<?php

namespace App\Controllers;

class CurahHujan extends BaseController
{
	public function index()
	{
		echo view('header');
		echo view('layout/curahhujan');
		echo view('footer');
	}
}
