 <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->

    <div class="mt-5" style="background:black;">
          <div class="container">
            <div class="row pt-4">

            <!-- colom 1 -->
           
              <div class="col-4" style="color:white;">

                <img src="asset/bmkg.png" alt="" height="80px" style="border-radius: 15px;">
                <h4 class="mt-2">Kantor Pusat</h4>
                <p>Jl. Angkasa I No.2 Kemayoran
                <br>
                Jakarta Pusat, DKI Jakarta 10610
                <br>
                PO Box 3540 Jkt.</p>

                <h4 class="mt-2">Tel.& Fax</h4>
                <p>Call Center (021) 196  
                <br>
                Fax (021) 4246703</P>

                <h4 class="mt-2">Email:</h4>
                <p>info@bmkg.go.id</p>

              </div>
              
              <!-- colom 2 -->
              <div class="col-4" style="color:white;">

                <h4 class="mt-2">LINK BMKG</h4>
                <li class="item">
                  <a class="link" style="color:white;" href="http://web.meteo.bmkg.go.id/id/" >Informasi Cuaca</a>
                </li>
                <li class="item">
                  <a class="link" style="color:white;" href="https://maritim.bmkg.go.id/" >Cuaca Maritim</a>
                </li>
                <li class="item">
                  <a class="link" style="color:white;" href="http://aviation.bmkg.go.id/web/" >Cuaca Penerbangan</a>
                </li>
                <li class="item">
                  <a class="link" style="color:white;" href="https://dataonline.bmkg.go.id/home" >Data Online BMKG</a>
                </li>
                <li class="item">
                  <a class="link" style="color:white;" href="https://mail.bmkg.go.id/" >Email BMKG</a>
                </li>

              </div>
              
              <!-- colom3 -->
              <div class="col-4" style="color:white;">

                <h4 class="mt-2">APLIKASI MOBILE</h4>
                <li class="item">
                  <a class="link"  href="https://apps.bmkg.go.id/" >Info BMKG - Cuaca, Iklim, dan Gempabumi
                  <br>
                  Indonesia</a>
                </li>
                <p>Semua informasi mengenai Prakiraan Cuaca,
                <br>  
                Iklim, Kualitas Udara, dan Gempabumi yang
                <br>
                terjadi di berbagai wilayah di Indonesia
                <br>
                tercakup dalam satu aplikasi mobile.</p>
                <a href="https://apps.apple.com/id/app/id1114372539?l=id">
                <img src="asset/apple.JPG" alt="" height="40px">
                </a>
                <a href="https://play.google.com/store/apps/details?id=com.Info_BMKG">
                <img src="asset/play.jpg" alt="" height="40px">
                </a>

                </div>
              
            </div>
          </div>
          <div style="background-color:grey; font-size:15px; color:white;" class="text-center">
          <p>© 2021-Badan Meteorologi, Klimatologi,dan Geofisika Jawa Tengah</p>
  
          </div>
        </div>
        
        




  </body>

  

</html>