<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- <link rel="stylesheet" type="text/css" href="<?base_url('assets/css/style.css') ?>"> -->
    <title>BMKG JAWA TENGAH</title>
    
    <!-- jam -->
    <link rel="stylesheet" href="style2.css">
    <meta http-equiv="Content-Language" content="en-us">
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="-1">
    <meta http-equiv="refresh" content="120">
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <title>:: Server Jam BMKG (BMKG NTP Server) ::</title>
    <link rel="shortcut icon" href="icon/iconlogo.png" type="image/ico" />
  </head>
  <body>

<style>
    body{
         background-color: 	#E0FFFF;
    }
</style>

  <center><img src="asset/Capture back.png" class="img-fluid" alt="Responsive image" style=" height: 200px" width="100%"></center>

  <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ">
                <li class="nav-item">
                <a class="nav-link"  aria-current="page" href="Home">Beranda</a>
                </li> 
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Profil
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="Sejarah">Sejarah</a></li>
                    <li><a class="dropdown-item" href="VisiMisi">Visi & Misi</a></li>
                    <li><a class="dropdown-item" href="TugasFungsi">Tugas & Fungsi</a></li>
                </ul>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="Meteorologi">Meteorologi</a>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Klimatologi
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="Kekeringan">Peringatan Dini Kekeringan Meteorologis</a></li>
                    <li><a class="dropdown-item" href="CurahHujanTinggi">Peringatan Dini Curah Hujan Tinggi</a></li>
                    <li><a class="dropdown-item" href="Musim">Prakiraan Musim</a></li>
                    <li><a class="dropdown-item" href="CurahHujan">Prakiraan Curah Hujan</a></li>
                    <li><a class="dropdown-item" href="Banjir">Prakiraan Daerah Potensi Banjir Bulanan</a></li>

                </ul>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Geofisika
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="Gempaterkini">Gempa Bumi Terkini</a></li>
                    <li><a class="dropdown-item" href="Gempadirasakan">Gempa Bumi Dirasakan</a></li>
                    <li><a class="dropdown-item" href="Gempaterbaru">Gempa Bumi Terbaru</a></li>
                </ul>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Publikasi
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="Linkyt">Link Youtube</a></li>
                    <li><a class="dropdown-item" href="Buletin">Buletin</a></li>
                    <li><a class="dropdown-item" href="Brosur">Brosur</a></li>
                </ul>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="Survey">Survey</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="Pengaduan">Pengaduan</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="Warning">Warning</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>

    <div style="background-color: primary;">
<link rel="stylesheet" href="style2.css">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<meta http-equiv="refresh" content="60">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>:: Server Jam BMKG (BMKG NTP Server) ::</title>
<link rel="shortcut icon" href="icon/iconlogo.png" type="image/ico" />
<script language="JavaScript" src="http://time.bmkg.go.id/JamServer.php"></script>

<script language="JavaScript">

var weekdaystxt=["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
var monthstxt=["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]

var deltaD = (servertimeOBJ.getTime())-(new Date().getTime());
var displaySeconds = true; 
var interval;

function textdates(){
getthedate();
if (document.all||document.getElementById)
t=setTimeout("textdates()", interval); 
}

function getthedate(){
var clientDate = new Date();
var serverdate = new Date(clientDate.getTime()+deltaD);
var month=serverdate.getMonth()+1;
var day=serverdate.getDate();
var year=serverdate.getFullYear();
var hours=serverdate.getHours();
var minutes=serverdate.getMinutes();
var seconds=serverdate.getSeconds();
var milliseconds=serverdate.getMilliseconds();
//var dn="AM";
var minggu=weekdaystxt[serverdate.getDay()]
var bulan=monthstxt[serverdate.getMonth()]
//if (hours>=12){dn="PM";}
//if (hours>12){hours=hours-12;}
//if (hours==0){hours=12;}
if (hours<=9){hours="0"+hours;}
if (minutes<=9){minutes="0"+minutes;}
//if (month<=9){month="0"+month;}
//if (day<=9){day="0"+day;}

if (displaySeconds){
	if (seconds<=9){seconds="0"+seconds;}
	if (milliseconds>=10&&milliseconds<=99){milliseconds="0"+milliseconds;}
	if (milliseconds<10){milliseconds="00"+milliseconds;}
//	var cdate="<div class='FontHari'>"+minggu+", "+day+" "+bulan+" "+year+"</div><div class='FontDigit'>"+hours+":"+minutes+":"+seconds+":"+milliseconds+" "+dn+" WIB</div>";
//	interval = 1000 - serverdate.getMilliseconds(); 
	var cdate="<div class='FontHari'>"+minggu+", "+day+" "+bulan+" "+year+"</div><div class='FontDigit'>"+hours+":"+minutes+":"+seconds+":"+milliseconds+" WIB</div>";
	interval = 10; 
	}
else{
//	var cdate="<div class='FontHari'>"+minggu+", "+day+" "+bulan+" "+year+"</div><div class='FontDigit'>"+hours+":"+minutes+" "+dn+" WIB</div>";
	var cdate="<div class='FontHari'>"+minggu+", "+day+" "+bulan+" "+year+"</div><div class='FontDigit'>"+hours+":"+minutes+" WIB</div>";
	interval = (60-seconds)*1000; 
	}
if (document.all)
document.all.sTime.innerHTML=cdate;
else if (document.getElementById)
document.getElementById("sTime").innerHTML=cdate;
else{
document.write(cdate);
}
}
</script>
</head>

<body onLoad="textdates()" bgcolor="#222222" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<center>
<table width="100%" height="93%"><tr><td width="100%" height="100%" align="center" valign="middle">
<div align="center">
<span id="sTime" OnMouseOver="displaySeconds=true;textdates();" OnMouseOut="displaySeconds=false;">sinkronisasi jam server ...</span>
</div>
</td></tr></table>
<div class="Jam">
<!-- <a href="JamServerFD-WU.html">WIB & UTC Time</a> 
&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; 
<a href="JamServerFS.html">Standard Font</a>
&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; 
<a href="#" onClick="location.reload(true);return false;">Reload</a> -->
</div>
</center>
</center>	
</body>