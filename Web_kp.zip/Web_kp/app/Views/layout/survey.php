<div class="container mt-2 shadow p-3 mb-5 bg-body rounded" style="background-color: white;" >
<form>
    <center><h2>Jenis Layanan Yang Dipilih</h2></center>
    <center><h5><label class="form-label">METEOROLOGI</label></h5></center>

    <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi cuaca publik (rutin, peringatan, dini cuaca, pasang surut air laut)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi cuaca khusus (maritim, penerbangan, klaim asuransi)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Analisis cuaca (kecelakaan pesawat, kecelakaan kapal laut)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi titik panas(hotspot)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">lnformasi tentang tingkat kemudahan terjadinya kebakaran hutan dan lahan</label>
  </div>

  <center><h5><label class="form-label">KLIMATOLOGI</label></h5></center>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Prakiraan musim</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi iklim khusus</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Analisis dan prakiraan curah hujan bulanan/dasarian</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Tren curah hujan</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi kualitas udara</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Analisis iklim ekstrim</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">lnformasi iklim terapan (peta potensi energi baru terbarukan, informasi potensi DBD, dst)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi perubahan iklim (keterpaparan dan/atau proyeksi)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Pengambilan dan pengujian sampel parameter iklim dan kualitas udara(laboratorium)</label>
  </div>

  <center><h5><label class="form-label">GEOFISIKA</label></h5></center>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi gempabumi dan peringatan dini tsunami</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Peta seismisitas</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">lnformasi tanda waktu(hilal dan gerhana)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">lnformasi geofisika potensial(gravitasi, magnet bumi, dan hari guruh/petir)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Peta rendaman tsunami</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Informasi seismologi teknik(shake map)(peta mikrozonasi dan percepatan tanah)</label>
  </div>

  <center><h5><label class="form-label">INSTRUMENTASI</label></h5></center>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Data meteorologi, klimatologi, dan geofisika(suhu, curah hujan, angin, dan grid)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Kalibrasi (peralatan MKG)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Konsultasi(untuk penerapan informasi khusus MKG)</label>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Sewa peralatan MKG</label>
  </div>
  <center><button type="submit" class="btn btn-primary">Submit</button></center>
</form>
    </div>