<!-- Awal daftar -->
<div class="card mt-3">
  <div class="card-header bg-primary text-white">
    Daftar Pengaduan
  </div>
  <div class="card-body">

  <table class="table table-bordered table-striped">
    <tr>
      <th>No</th>
      <th>Nama</th>
      <th>Nomor Whatsapp</th>
      <th>Alamat</th>
      <th>Tanggal Kejadian</th>
      <th>Aduan</th>
      <th>Opsi</th>
    </tr>
    <?php
      $no = 1;
      $tampil = mysqli_query($koneksi, "SELECT * from tform order by id_plp desc");
      while($data = mysqli_fetch_array($tampil)) :
    ?>
    <tr>
      <td><?=$no++;?></td>
      <td><?=$data['Nama']?></td>
      <td><?=$data['Nomor Whatsapp']?></td>
      <td><?=$data['Alamat']?></td>
      <td><?=$data['Tanggal Kejadian']?></td>
      <td><?=$data['Aduan']?></td>
      <td>
        <a href="#" class="btn btn-warning">Edit </a>
        <a href="#" class="btn btn-danger">Hapus </a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
  </div>
</div>
<!-- Akhir daftar -->