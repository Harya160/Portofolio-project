<style>
    #map{
        height: 100%;
        width: 100%;
    }
</style>

<div id="map"></div>

    