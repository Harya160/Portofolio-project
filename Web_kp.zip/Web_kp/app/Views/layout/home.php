<div class="container">
            <div class="row mt-2 shadow p-3 mb-5 bg-body rounded" style="background-color: white;">

            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="asset/INFORMASI.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="asset/INFORMASI2.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="asset/INFORMASI3.png" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>           

<div class="col-6 mt-5">
<?php
	$data = simplexml_load_file("https://data.bmkg.go.id/DataMKG/MEWS/DigitalForecast/DigitalForecast-JawaTengah.xml") or die ("Gagal ambil!");
	echo "<h2>Daftar Cuaca Jawa tengah</h2>";
	$i = 0;
  function weather_text($index){
    switch ($index) {
      case 0  : return "Cerah";
      case 1  : return "Cerah Berawan";
      case 2  : return "Cerah Berawan";
      case 3  : return "Berawan";
      case 4  : return "Berawan Tebal";
      case 5  : return "Udara Kabur";
      case 10 : return "Asap";
      case 45 : return "Kabut";
      case 60 : return "Hujan Ringan";
      case 61 : return "Hujan Sedang";
      case 63 : return "Hujan Lebat";
      case 80 : return "Hujan Lokal";
      case 95 : return "Hujan Petir";
      case 97 : return "Hujan Petir";
    }
    return "Unknown";
  }
?>
<table>
  <thead>
    <tr>
      <td>NO.</td>
      <td>Kota</td>
      <td>Cuaca hari ini</td>
      <td>Cuaca Besok</td>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data->forecast->area as $item){
      $name             = $item->name;
      $temperature_min  = $item->xpath('parameter[@id="tmin"]/timerange/value[@unit="C"]');
      $temperature_max  = $item->xpath('parameter[@id="tmax"]/timerange/value[@unit="C"]');
      $humidity_min     = $item->xpath('parameter[@id="humin"]/timerange/value');
      $humidity_max     = $item->xpath('parameter[@id="humax"]/timerange/value');
      $wind_speed       = $item->xpath('parameter[@id="ws"]/timerange');
      $wind_direction   = $item->xpath('parameter[@id="wd"]/timerange');

  ?>
    <tr>
      <td><?= ++$i ?></td>
      <td><?= $name ?></td>
      <td>
        <?= @weather_text($item->xpath('parameter[@id="weather"]/timerange[@h="0"]/value')[0])?><br>
        Suhu: <?= @$temperature_min[0] ?> - <?= @$temperature_max[0] ?>&deg;C<br>
        Kelembaban: <?= @$humidity_min[0] ?> - <?= @$humidity_max[0] ?>%
      </td>
      <td>
          <?= @weather_text($item->xpath('parameter[@id="weather"]/timerange[@h="24"]/value')[0])?> <br>
          Suhu: <?= @$temperature_min[1] ?> - <?= @$temperature_max[1] ?>&deg;C<br>
          Kelembaban: <?= @$humidity_min[1] ?> - <?= @$humidity_max[1] ?>%
      </td>
    </tr>
  <?php
    }
    if($i == 0) echo '<tr><td colspan="8" align="center">Data tidak ada</td></tr>';
  ?>
  </tbody>
</table>
</div>

<div class="col-5 mt-5">
<?php
  // Kode Baris PHP untuk Mengolah Data autogempa.xml
  $data = simplexml_load_file("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.xml") or die("Gagal mengakses!");
  echo "<h2>Gempabumi Terbaru</h2>";
  echo "<br><img src=\"https://data.bmkg.go.id/DataMKG/TEWS/" . $data->gempa->Shakemap . "\" alt=\"Gempabumi Terbaru\">";
  echo "Tanggal: " . $data->gempa->Tanggal . "<br>";
  echo "Jam: " .  $data->gempa->Jam . "<br>";
  echo "DateTime: " . $data->gempa->DateTime . "<br>";
  echo "Magnitudo: " . $data->gempa->Magnitude . "<br>";
  echo "Kedalaman: " . $data->gempa->Kedalaman . "<br>";
  echo "Koordinat: " . $data->gempa->point->coordinates . "<br>";
  echo "Lintang: " . $data->gempa->Lintang . "<br>";
  echo "Bujur: " . $data->gempa->Bujur . "<br>";
  echo "Lokasi: " . $data->gempa->Wilayah . "<br>";
  echo "Potensi: " . $data->gempa->Potensi . "<br>";
  echo "Dirasakan: " . $data->gempa->Dirasakan . "<br>";
?>
<br>
<br>
<center><h1 class="mt-2">NEWS</h1></center>
<div class="row mt-2 shadow p-3 mb-5 bg-body rounded" style="background-color: primary;">
<img class="mt-3" src="asset/hilal.jpg" alt="" height="200" width="50">
  <li class="item">
    <a class="link" style="color:black;" href="https://www.bmkg.go.id/press-release/?p=informasi-prakiraan-hilal-saat-matahari-terbenam-tanggal-8-dan-9-agustus-2021-penentu-awal-bulan-muharam-1443-h&tag=press-release&lang=ID" >Informasi Prakiraan Hilal saat Matahari Terbenam Tanggal 8 dan 9 AGustus 2021 (Penentu Awal Bulan Muharam 1443 H)</a>
  </li>
  <img class="mt-3" src="asset/bandicam.jpg" alt="" height="200" width="50">
  <li class="item">
    <a class="link" style="color:black;" href="https://www.bmkg.go.id/press-release/?p=presiden-minta-k-l-dan-pemda-jadikan-data-bmkg-rujukan-kebijakan&tag=press-release&lang=ID" >Presiden Minta K/L dan Pemda Jadikan Data BMKG Rujukan Kebijakan</a>
  </li>
  <img class="mt-3" src="asset/gb.jpg" alt="" height="200" width="50">
  <li class="item">
    <a class="link" style="color:black;" href="https://www.bmkg.go.id/press-release/?p=74-tahun-mengawal-indonesia-ini-deretan-kiprah-bmkg-di-berbagai-sektor&tag=press-release&lang=ID" >74 Tahun Mengawal Indonesia, Ini Deretan Kiprah BMKG di Berbagai Sektor</a>
  </li>
  <img class="mt-3" src="asset/bm.png" alt="" height="200" width="50">
  <li class="item">
    <a class="link" style="color:black;" href="https://www.bmkg.go.id/press-release/?p=bmkg-update-prakiraan-cuaca-di-wilayah-indonesia-dalam-sepekan-kedepan-16-23-juli-2021&tag=press-release&lang=ID" >BMKG: Update Prakiraan Cuaca di Wilayah Indonesia dalam Sepekan ke Depan (16-23 Juli 2021)</a>
  </li>
</div>
 </div>
</div>
</div>



