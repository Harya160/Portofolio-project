<!-- form -->

<!-- <form action="/Pengaduan/save" method="post">
 
  <div class="mb-3">
    <label for="Nama" class="form-label">nama</label>
    <input type="text" class="form-control" id="Nama" name="Nama">
  </div>
  <div class="mb-3">
    <label for="Nomor Whatsup" class="form-label">nomor</label>
    <input type="text" class="form-control" id="Nomor Whatsup">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form> -->

<div class="card mt-3">
  <div class="card-header bg-primary text-white">
    Layanan Pengaduan
  </div>
  <div class="card-body">
   <form action="/Pengaduan/save" method="post">
   <?= csrf_field(); ?>
   <div class="form-group" >
   	<label>Nama</label>
   	<input type="text" id="Nama" name="Nama" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Nomor Whatsapp</label>
   	<input type="text" id="Nomor Whatsapp"name="Nomor Whatsapp" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Alamat</label>
   	<textarea id="Alamat"class="form-control" name="Alamat"></textarea>
   </div>
   <div class="form-group">
   	<label>Tanggal Kejadian</label>
   	<input id="Tanggal Kejadian"type="date" name="Tanggal Kejadian" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Aduan</label>
   	<input id="Aduan"type="text" name="Aduan" class="form-control" required>
   </div>

		   	<button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
		   	<!-- <button type="Reset" class="btn btn-danger" name="breset">Reset</button> -->

		</form>
  </div>
</div>

<!-- table
    
    <table class="table">
    <thead>
        <tr>
        <th scope="col">Nama</th>
        <th scope="col">Nomor Whatsapp</th>
        <th scope="col">Alamat</th>
        <th scope="col">Tanggal Kejadian</th>
        <th scope="col">Aduan</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($form as $k) : ?> 
        <tr>
        <td><?= $k['Nama']; ?> </td>
        <td><?= $k['Nomor Whatsapp']; ?></td>
        <td><?= $k['Alamat']; ?></td>
        <td><?= $k['Tanggal Kejadian']; ?></td>
        <td><?= $k['Aduan']; ?></td>
        </tr>
        <?php endforeach; ?> 

    </tbody>
    </table> -->