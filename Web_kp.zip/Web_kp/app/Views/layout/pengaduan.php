<?php
  // $server = "localhost";
  // $user = "root";
  // $pass = "";
  // $database = "form";

  // $koneksi = mysqli_connect($server, $user, $pass, $database)or die(mysqli_error($koneksi));

  // if(isset($_POST['bsimpan']))
  // {
  //   $simpan = mysqli_query($koneksi, "INSERT INTO tform (nama, nomor whatsapp, alamat, tanggal kejadian, aduan)
  //                                     VALUES ('$_POST[tnama]',
  //                                             '$_POST[tnomorwhatsapp]',
  //                                             '$_POST[talamat]',
  //                                             '$_POST[ttanggalkejadian]',
  //                                             '$_POST[aduan]')
  //                                     ");
  //   if($simpan)
  //   {
  //     echo "<script>
  //             alert('Pengaduan Sukses!');
  //             document.location='pengaduan.php';
  //           </script>";
  //   }
  //   else
  //   {
  //     echo "<script>
  //             alert('Pengaduan Gagal!');
  //             document.location='pengaduan.php';
  //           </script>";
  //   }
  // }
?>

<!-- <!doctype html>
<html lang="en">
<head>
	<title>PENGADUAN</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5 shadow p-3 mb-5 bg-body rounded">

		<h1 class="text-center"> Layanan Pengaduan</h1> -->
<!-- Awal form -->
		<div class="card mt-3">
  <div class="card-header bg-primary text-white">
    Layanan Pengaduan
  </div>
  <div class="card-body">
   <form method="post" action="">
   <div class="form-group">
   	<label>Nama</label>
   	<input type="text" name="tnama" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Nomor Whatsapp</label>
   	<input type="text" name="tnomorwhatsapp" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Alamat</label>
   	<textarea class="form-control" name="talamat"></textarea>
   </div>
   <div class="form-group">
   	<label>Tanggal Kejadian</label>
   	<input type="text" name="ttanggalkejadian" class="form-control" required>
   </div>
   <div class="form-group">
   	<label>Aduan</label>
   	<input type="text" name="tAduan" class="form-control" required>
   </div>

		   	<button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
		   	<button type="Reset" class="btn btn-danger" name="breset">Reset</button>

		</form>
  </div>
</div>
<!-- Akhir form -->



<!-- </div>

		<script type="text/javascript" src="js/bootstrap.min.js"></script>
	</body>
</html> -->

