<div class="container">
	<div class="row mt-2 shadow p-3 mb-5 bg-body rounded" style="background-color: white;">
		<div class="col">
			<div>
				<h1> Tugas & Fungsi</h1>
                <p>
                Tugas dan Fungsi
                BMKG mempunyai status sebuah Lembaga Pemerintah Non Departemen (LPND), dipimpin oleh seorang Kepala Badan.
                </p>
            </div>
            <div>
                <h1> Tugas </h1>
                <p>
                    BMKG mempunyai tugas : melaksanakan tugas pemerintahan di bidang Meteorologi, Klimatologi, Kualitas Udara dan Geofisika sesuai dengan ketentuan perundang-undangan yang berlaku.
                </p>
            </div>
            <div>
                <h1> Fungsi</h1>
                <p>
                Dalam melaksanakan tugas sebagaimana dimaksud di atas, Badan Meteorologi Klimatologi dan Geofisika menyelenggarakan fungsi :
                Perumusan kebijakan nasional dan kebijakan umum di bidang meteorologi, klimatologi, dan geofisika;
                Perumusan kebijakan teknis di bidang meteorologi, klimatologi, dan geofisika;
                Koordinasi kebijakan, perencanaan dan program di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan, pembinaan dan pengendalian observasi, dan pengolahan data dan informasi di bidang meteorologi, klimatologi, dan geofisika;
                Pelayanan data dan informasi di bidang meteorologi, klimatologi, dan geofisika;
                Penyampaian informasi kepada instansi dan pihak terkait serta masyarakat berkenaan dengan perubahan iklim;
                Penyampaian informasi dan peringatan dini kepada instansi dan pihak terkait serta masyarakat berkenaan dengan bencana karena faktor meteorologi, klimatologi, dan geofisika;
                Pelaksanaan kerja sama internasional di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan penelitian, pengkajian, dan pengembangan di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan, pembinaan, dan pengendalian instrumentasi, kalibrasi, dan jaringan komunikasi di bidang meteorologi, klimatologi, dan geofisika;
                Koordinasi dan kerja sama instrumentasi, kalibrasi, dan jaringan komunikasi di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan pendidikan dan pelatihan keahlian dan manajemen pemerintahan di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan pendidikan profesional di bidang meteorologi, klimatologi, dan geofisika;
                Pelaksanaan manajemen data di bidang meteorologi, klimatologi, dan geofisika;
                Pembinaan dan koordinasi pelaksanaan tugas administrasi di lingkungan BMKG;
                Pengelolaan barang milik/kekayaan negara yang menjadi tanggung jawab BMKG;
                Pengawasan atas pelaksanaan tugas di lingkungan BMKG;
                Penyampaian laporan, saran, dan pertimbangan di bidang meteorologi, klimatologi, dan geofisika.
                Dalam melaksanakan tugas dan fungsinya BMKG dikoordinasikan oleh Menteri yang bertanggung jawab di bidang perhubungan.
                </p>
            </div>
		</div>
	</div>
</div>	