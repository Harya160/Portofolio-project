        <!-- colom 1 -->
        <div class="container">
            <div class="row">
                <div class="col-md-6 mt-4">
                    <h2>Prakiraan Cuaca Rabu, 28 Juli 2021</h2>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/ENFCaP7Vyqk"></iframe>

                    <h2>Prakiraan Cuaca Kamis, 29 Juli 2021</h2>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/UIBV74MuMR0"></iframe>
                </div>       
            <!-- colom 2 -->

                <div class="col-md-6 mt-4">
                    <h2>Prakiraan Cuaca Jumat, 30 Juli 2021</h2>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/UFsVwZXhUkA"></iframe>

                    <h2>Prakiraan Cuaca Sabtu, 31 Juli 2021</h2>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/UIBV74MuMR0"></iframe>
                </div>
            </div>   
        </div>   

