<!DOCTYPE html>
<html>
<head>
	<title>Prakiraan Cuaca Jawa Tengah</title>

	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="robot" content="index,follow">
	<meta name="googlebot" content="index,follow">
	<meta property="og:image" content="https://smartdevtala.com/assets/unggah/icon/logoku-circle.png">
	<meta property="og:image:secure_url" content="https://smartdevtala.com/assets/unggah/icon/logoku-circle.png">
	<meta property="og:image:type" content="image/png">
	<meta property="og:image:width" content="100">
	<meta property="og:image:height">
	<!-- Meta -->
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
	   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
	   crossorigin=""/>
	   <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	  <style type="text/css">
	  	body{
	  		padding: 0;
	  		margin: 0;
	  		font-family: 'Roboto', sans-serif;
	  	}
	  	#map{
	  		height: 80vh;
	  		width: 100%;
            margin-top: 10px;
	  	}
	  	header{
	  		/* position: absolute; */
	  		/* top:380px;
	  		left:50px; */
	  		z-index: 1000;
	  		background: #fffd;
	  		padding: 10px 20px;
	  		width: 100%;
	  	}
	  	header h1{
	  		padding: 0;
	  		margin: 0 0  5px;
	  		font-size: 22px
	  	}
	  	header p{
	  		padding: 0;
	  		margin: 0;
	  		font-size: 14px;
	  	}
	  	header .select{
	  		position: absolute;
	  		right: 20px;
	  		top: 1rem
	  	}
	  	header .select>select{
	  		font-size: 1rem;
	  		padding: .5rem;
	  		border:1px solid #ddd !important;
	  	}
	  </style>
</head>
<body>
	<header>
		<div class="title text-center">
			<h1>Prakiraan Cuaca Jawa Tengah</h1>
			<p>Date : <span class="tanggal"></span></p>
		</div>
		<div class="select">
			<select name="select-tanggal"></select>
		</div>
	</header>
    <div class="container">
	<div id="map"></div>
    </div>

</body>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>
   <script type="text/javascript" src="node_modules/moment/moment.js"></script>
   <script type="text/javascript" src="asset/app.js"></script>
</html>