-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 03 Agu 2021 pada 05.34
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tform`
--

CREATE TABLE `tform` (
  `Nama Pelapor` varchar(100) CHARACTER SET latin1 NOT NULL,
  `Nomor Whatsapp` varchar(15) CHARACTER SET latin1 NOT NULL,
  `Alamat` varchar(200) CHARACTER SET latin1 NOT NULL,
  `Tanggal Kejadian` date NOT NULL,
  `Aduan` varchar(500) CHARACTER SET latin1 NOT NULL,
  `id_plp` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tform`
--

INSERT INTO `tform` (`Nama Pelapor`, `Nomor Whatsapp`, `Alamat`, `Tanggal Kejadian`, `Aduan`, `id_plp`) VALUES
('ivan', '085626262', 'bandung', '2021-08-20', 'bagus', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tform`
--
ALTER TABLE `tform`
  ADD PRIMARY KEY (`id_plp`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tform`
--
ALTER TABLE `tform`
  MODIFY `id_plp` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
