<?php

namespace App\Models;

use CodeIgniter\Model;

class FormModel extends Model
{
    protected $table      = 'form_adu';
    protected $allowedFields = ['Nama', 'Nomor Whatsapp', 'Alamat', 'Tanggal Kejadian', 'Aduan'];
}